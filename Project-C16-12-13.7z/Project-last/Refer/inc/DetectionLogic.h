#ifndef _DetectionLogic_H_
#define _DetectionLogic_H_

#include "mcuhead.h"
#include "PID.h"

//--------��·�滮-----------
//·������
extern u8 *PathList;
//·��ִ��λ��
extern u16 PathPos;
//·������
extern u16 PathLen;

extern u8 PathSelect;

extern PIDStruct LeftMotor;
extern PIDStruct RightMotor;

extern s8 MotorLeftSpeed;
extern s8 MotorRightSpeed;

extern s16 Yaw;

extern u8 ReturnTime;
extern u8 lastCheckStatus;
extern u8 WayCentreCount;
extern u8 CentreWayTime;
extern s8 turnSpeed;
typedef struct {
	u8(*GetDIR)(void);

	//����ָ������
	u8(*ActionRun)(u8 DIR);
	
	//ֹͣ����״̬������
	void(*StopRun)(void);

	//��ȡ�������е�ʣ��ʱ��
	u16(*GetActionTime)(void);
	
	void(*SetActionTime)(u16);

	//��ȡ���õ�·
	u8(*GetPath)();

	//��ȡ����·����
	u8(*GetPathCount)(void);

	//��ȡ������Ĵ���
	u8(*GetLastError)(void);
}ActionInfoBase;

typedef ActionInfoBase* ActionData;

typedef struct {
	u8 EnterWay;
	u8 turnFail;
	u8 turnDone;
	u8 turnPreDone;
	u8 EnterPoint;
}ActionTypeBase;
extern const ActionTypeBase ActionType;
typedef struct
{
	u8 NullDetection;
	u8 AngleOut;
}FailTypeBase;
extern const FailTypeBase FailType;

typedef void(*ActionEvent)(ActionData);

typedef struct {
	u8 Forward;
	u8 Left;
	u8 Right;
}PathTypeBase;
extern const PathTypeBase PathType;

typedef enum {
	Forward = 0,
	Left = 1,
	Right = 2,
	Back = 3,
}Direction;

typedef struct 
{
	u8 CheckWay;
	u8 ConfirmWay;
	u8 ReturnWay;
	u8 PreTurn;
	u8 TurnWay;
	u8 TurnDone;
	u8 Stop;
}CheckStatusBase;

extern const CheckStatusBase CheckStatus;

typedef u8(*DisableCallBack)(void);

typedef struct {
	void(*Init)(void);
	void(*LogicRun)(void);
	void(*SetDisableCheck)(DisableCallBack callback);
	void(*RegisterEvent)(u8 type, ActionEvent event);
	void(*LoadDefConfig)(u8* buff);
	ActionData Control;
}DetectionLogicBase;

extern const DetectionLogicBase DetectionLogic;

#endif
