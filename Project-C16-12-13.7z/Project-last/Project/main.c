#include "delay.h"
#include "led.h"
#include "wave.h"
#include "motor.h"
#include "pid.h"
#include "sensor.h"
#include "timer.h"
#include "Uart.h"
#include "UartProtocol.h"
#include "mpu6050.h"
//#include "inv_mpu_dmp_motion_driver.h"
//#include "inv_mpu.h"
#include "DetectionLogic.h"
#include "RC522.h"
#include "adc.h"
#include "pathfind.h"


u8 buffdata[ RECV_BUFF_LEN+SEND_BUFF_LEN ];
u8 pathdatabuff[PathFindBuffSize];
u16 flen=0xffff,blen=0xffff;
u16 lastflen=0xffff,lastblen=0xffff;
u16 detectionlenght=200;

//u8 sid=0;
//u8 rot=0;

u8 pathbuff[512];
u8 encodebuff[512];

u16 sendpos;
u16 sendlen;

u16 lastAction;
u16 lastCodeID;
u8 EnableTime=0;
u32 lastTick;
u32 lastTime;
u32 lastIDCard;
u16 lastLenght;
u8 RecvCode;

u8 AutoFind=0;

u8 AveSpeedL=10;
u8 AveSpeedR=10;
u8 statusRL=0;

u8 nowdir[4];
u8 nowid;
u8 lastid;
u8 lastdir;

u8 StartNodeID;
u8 TargetNodeID=0xff;

u8 FindStatus=0;//Ѱ·״̬

u8 keycount=0;
u8 newmap=1;
void BatteryCheckInit(){
	GPIO_AI(GPIOA,0,00000010);
	SETBIT(GPIOA->ODR,BIT1);
}


#define ADCBit 12
#define ADCVOP 3300
#define ADCLsb (31-ADCBit)

u16 toVoltage(u16 value) {
	u32 v = value;
    v <<=ADCLsb;
	v /= (((u32)1<<(ADCBit+ADCLsb))/ADCVOP);
	return v;
}


#define Lbattery (u32)10800 //�����͵�ѹ
#define Hbattery (u32)12600 //�����ߵ�ѹ
#define R1 (u32)995       //��ѹ������ֵ
#define R2 (u32)196         
#define RV(v) ((v * (R1+R2)) / R2)

//��ȡ����0-100%
u8 getBatteryValue() {
	u32 v = toVoltage(ADC.getADCValue(1));
	v = RV(v);
	if (v < Lbattery)return 0;
	if (v > Hbattery)v = Hbattery;
	return (v - Lbattery) * 100 / (Hbattery - Lbattery);
}

u8 lastBatteryValue;
void UpdateBatteryValue(){
	lastBatteryValue=getBatteryValue();
}

//void rsPath(){
//	u8 tid=lastid=PathFind.Finder->lastNodeID;
//	nowdir[0]=PathFind.Finder->paths[0];
//	nowdir[1]=PathFind.Finder->paths[1];
//	nowdir[2]=PathFind.Finder->paths[2];
//	nowdir[3]=PathFind.Finder->paths[3];
//	PathLen= PathFind.getTargetPath(sid,pathbuff);
//	if(PathLen!=0)
//	{
//		sid=tid;
//		PathPos=0;
//		PathFind.Rotate(nowdir,pathbuff[0]);
//		nowid=PathFind.getNode(lastid)->nodes[nowdir[Forward]];
//		DetectionLogic.Control->ActionRun(pathbuff[0]);
//	}
//}

#define KeyStatus() (GPIOC->IDR&BIT3)

void KeyLoad(){
	if(!KeyStatus()){
		if(++keycount==50){
				if(PathPos==0xffff&&TargetNodeID!=0xff)
				{
					if(RecvCode!=4)
					{
						TargetNodeID=StartNodeID;
						StartNodeID=PathFind.Finder->lastNodeID;
						RecvCode=4;
					}
					//rsPath();
				}
		}
		if(keycount>50)keycount=50;
		return;
	}
	else{
		keycount=0;
	}
}

void KeyInit(){
	RCC->APB2ENR|=RCC_APB2ENR_IOPCEN;
	GPIO_PU(GPIOC,0,00001000);
	SETBIT(GPIOC->ODR,BIT3);
}


void AliveEvent(UartEvent e)
{
	
}


//-------------------�������п����߼�--------------------------//
//#define pointback
void RunTurnDone(ActionData e){
	if(PathPos!=0xffff&&PathLen!=0)
	{
		PathPos++;
		lastTick=TimerTick;
	}
#ifdef pointback
	if(PathPos>PathLen&&PathLen!=0){
		e->StopRun();
	}
#endif
}
void RunInPoint(ActionData e){
	if(PathPos<PathLen){
		if(e->ActionRun(PathList[PathPos])){
			PathFind.Rotate(nowdir,PathList[PathPos]);
			lastid=nowid;
			nowid=PathFind.getNode(lastid)->nodes[nowdir[Forward]];
			lastLenght=PathFind.getNodeLenght(lastid,nowid);
			return;
		}
	}
	e->StopRun();
	PathPos=0xffff;
#ifdef pointback
	if(PathPos>=PathLen&&PathLen!=0){
		PathFind.Rotate(PathFind.Finder->paths,Back);
		e->ActionRun(Back);
	}
#endif
}
void RunInWay(ActionData e){
	if(PathPos<PathLen)
	{
		if(e->ActionRun(PathList[PathPos])){
			PathFind.Rotate(nowdir,PathList[PathPos]);
			lastid=nowid;
			nowid=PathFind.getNode(lastid)->nodes[nowdir[Forward]];
			lastLenght=PathFind.getNodeLenght(lastid,nowid);
			if(PathList[PathPos]==Forward){				
				lastTick=TimerTick;
				PathPos++;
			}
			return;
		}
	}
	e->StopRun();
	PathPos=0xffff;
}
void RunReadCard(u32 id){
	if(id){
		if(lastIDCard!=id)
		{
			lastIDCard=id;
			
		}
	}
}
//------------------��ͼɨ������߼�------------------------------//
ActionData lastactiondata;
u16 Actionlength;
void AutoFindTurnDone(ActionData e){
	lastTick=TimerTick;
}

void ActionDelay(){
	ActionData e=lastactiondata;
	u8 path;
	if(PathFind.getStatusFlag())
		PathFind.setLastLenght(Actionlength);
	lastid=PathFind.Finder->lastNodeID;
	path=PathFind.FindPath(PathSelect);
	nowid=PathFind.Finder->lastNodeID;
	if(!PathFind.getStatusFlag())
		lastLenght=PathFind.getNodeLenght(lastid,nowid);
	if(path==Forward)
		lastTick=TimerTick;	

	if(path!=0xff)
		e->ActionRun(path);
	else{
		FindStatus=0;
		DetectionLogic.RegisterEvent(ActionType.EnterWay,RunInWay);
		DetectionLogic.RegisterEvent(ActionType.turnDone,RunTurnDone);
		DetectionLogic.RegisterEvent(ActionType.EnterPoint,RunInPoint);
		RC522.SetCallBack(RunReadCard);
		turnSpeed=50;
		//RecvCode=0;
	}
	Timer.StopThis();
}

void AutoFindEvent(ActionData e){
	lastactiondata=e;
	Actionlength=(TimerTick-lastTick)/100;
	if(PathFind.getStatusFlag())
		Timer.GetHandle(Timer.Start(0,ActionDelay))->nTime=800;
	else
		Timer.Start(0,ActionDelay);
//	u8 path;
//	if(PathFind.getStatusFlag())
//		PathFind.setLastLenght((TimerTick-lastTick)/100);
//	lastid=PathFind.Finder->lastNodeID;
//	path=PathFind.FindPath(PathSelect);
//	nowid=PathFind.Finder->lastNodeID;
//	if(!PathFind.getStatusFlag())
//		lastLenght=PathFind.getNodeLenght(lastid,nowid);
//	if(path==Forward)
//		lastTick=TimerTick;	

//	if(path!=0xff)
//		e->ActionRun(path);
//	else{
//		FindStatus=0;
//		DetectionLogic.RegisterEvent(ActionType.EnterWay,RunInWay);
//		DetectionLogic.RegisterEvent(ActionType.turnDone,RunTurnDone);
//		DetectionLogic.RegisterEvent(ActionType.EnterPoint,RunInPoint);
//		RC522.SetCallBack(RunReadCard);
//		turnSpeed=50;
//		//RecvCode=0;
//	}
}

void AutoFindReadCard(u32 id)
{
	if(id!=0)
		if(lastIDCard!=id)
		{
			lastIDCard=id;
			Motor.Speed(0,0);
			Motor.Speed(1,0);
			if(PathFind.getFlagID(id)==0xff)
				PathFind.setLastFlag(id,(lastCheckStatus==CheckStatus.PreTurn||lastCheckStatus==CheckStatus.TurnWay)?1:0);
		}
}
//---------------------------------------------------------------//

void GetDataEvent(UartEvent e)
{
	SensorStatus val=Sensor.Read();
	e->WriteByte(lastCodeID);
	e->WriteWord(val);
	//e->WriteWord(flen);
	e->WriteWord(WayCentreCount);
	e->WriteWord(blen);
		
	e->WriteByte(MotorLeftSpeed);//lspeed
	e->WriteByte(MotorRightSpeed);//rspeed
	e->WriteByte(lastBatteryValue);
		//10
	e->WriteByte(RecvCode);	
		//��Ӧ��-��
		//Ŀ���
		//��ǰ����
		//��ǰ����
	switch(RecvCode){
		case 0://��������״̬
			lastTime=(TimerTick-lastTick)/lastLenght;
			if(lastTime>100)lastTime=100;
			e->WriteByte(lastCheckStatus);	
			e->WriteByte(PathSelect);
			e->WriteByte(lastTime);
			e->WriteByte(lastid);
			e->WriteByte(nowid);
			e->WriteByte(StartNodeID);
			e->WriteByte(TargetNodeID);
			break;
		case 1://Ѱ·״̬
			if(PathFind.getStatusFlag()){
				lastTime=(TimerTick-lastTick)/100;
				e->WriteByte(0);
			}
			else{
				lastTime=(TimerTick-lastTick)/lastLenght;
				if(lastTime>100)lastTime=100;
				e->WriteByte(1);
			}
			e->WriteByte(lastCheckStatus);			
			e->WriteByte(PathSelect);
			e->WriteByte(lastTime);
			e->WriteByte(lastid);
			e->WriteByte(nowid);
			e->WriteByte(PathFind.Finder->paths[Forward]);
			e->WriteByte(FindStatus);
			break;
		case 2://��ͼ����
			e->WriteWord(sendlen);
			e->WriteWord(sendpos);
			e->WriteWord((sendlen-sendpos)>32?32:sendlen-sendpos);
			e->WriteByte((sendlen-sendpos)<=32?0:1);
			e->WriteBuff(&encodebuff[sendpos],(sendlen-sendpos)>32?32:sendlen-sendpos);
			if((sendlen-sendpos)<=32)
				RecvCode=0;
			break;
		case 3://��ͼ����
			e->WriteWord(PathPos);
			break;
		case 4://����
			e->WriteByte(StartNodeID);
			e->WriteByte(TargetNodeID);
			break;
		case 5://̽��ر�
			e->WriteDWord(lastIDCard);
			break;
	}
	e->SendAckPacket();
}

void SetStartPos(){
	int i;
	PathNode *node=PathFind.getNode(i= PathFind.getFlagID(lastIDCard));
	if(i==0xff)return;
	PathFind.Finder->lastNodeID=nowid=i;
	PathFind.RotateReset(PathFind.Finder->paths);
	for(i=0;i<4;i++)
		if(node->nodes[i]!=0xff)
		{
			lastid=node->nodes[i];
			break;
		}
	PathFind.Rotate(PathFind.Finder->paths, PathFind.getNodeDir(lastid,nowid));
}

void SetDataEvent(UartEvent e)
{
	u8 id;
	s16 LS,RS;
	id=e->ReadByte();
	if(lastCodeID==id)return;
	lastCodeID=id;
	switch(e->ReadByte())
	{
		case 0://SetupPID
			RightMotor.P=LeftMotor.P=e->ReadByte();
			RightMotor.I=LeftMotor.I=e->ReadByte();
			RightMotor.D=LeftMotor.D=e->ReadByte();			
			break;
		case 1://SetWaveDetectionLenght+ReturnTime
			//CentreWayTime= e->ReadByte();
			detectionlenght= e->ReadByte();
			detectionlenght*=10;
			ReturnTime=e->ReadByte();
			break;
		case 2://PathRun
			switch(e->ReadByte())
			{
				case 0:PathSelect|=PathType.Forward; DetectionLogic.Control->ActionRun(Forward);lastAction=Forward;break;
				case 1:PathSelect|=PathType.Left; DetectionLogic.Control->ActionRun(Left);lastAction=Left;break;
				case 2:PathSelect|=PathType.Right; DetectionLogic.Control->ActionRun(Right);lastAction=Right;break;
				case 3:DetectionLogic.Control->ActionRun(Back);lastAction=Back;break;
			}
			if(newmap)
			{
				RecvCode=5;
				lastIDCard=0;
			}
			break;
		case 3://Motor Control
			AveSpeedL=e->ReadByte();
			AveSpeedR=e->ReadByte();
			id=e->ReadByte();
			MotorLeftSpeed=0;
			MotorRightSpeed=0;
			LS=RS=0;
			if(id&BIT0)
			{
				LS+=AveSpeedL;
				RS+=AveSpeedR;
			}
			if(id&BIT1){
				LS+=-AveSpeedL;
				RS+=+AveSpeedR;
			}
			if(id&BIT2){
				LS+=+AveSpeedL;
				RS+=-AveSpeedR;
			}
			if(id&BIT3){
				LS+=-AveSpeedL;
				RS+=-AveSpeedR;
			}
			if(LS>AveSpeedL)LS=AveSpeedL;
			if(LS<(s8)-AveSpeedL)LS=-AveSpeedL;
			if(RS>AveSpeedR)RS=AveSpeedR;
			if(RS<(s8)-AveSpeedR)RS=-AveSpeedR;
			Motor.Speed(0,MotorLeftSpeed=LS);
			Motor.Speed(1,MotorRightSpeed=RS);
			break;
		case 4://Stop Run
			DetectionLogic.Control->StopRun();
			PathLen=0;
			PathPos=0;
			RecvCode=0;
			break;
		case 5://Encode Send Map
			sendpos=e->ReadWord();
			if(sendpos==0xffff)
			{
				sendlen=PathFind.EncodeNode(encodebuff);
				sendpos=0;
			}
			RecvCode=2;
			break;
		case 6://Recv map Decode
			RecvCode=3;
			PathPos=e->ReadWord();
			PathLen=e->ReadByte();
			if(e->ReadByte())
				e->ReadBuff(&pathbuff[PathPos],PathLen);
			else{
				e->ReadBuff(&pathbuff[PathPos],PathLen);
				PathFind.DecodeNode(pathbuff);
				RecvCode=0;
				nowid=1;
				lastid=0;
				lastLenght=100;
				if(lastIDCard!=0)
					 SetStartPos();
				newmap=0;
			}
			break;
		case 7://Auto Find Map Mode On
			if((AutoFind=e->ReadByte())!=0){
				DetectionLogic.RegisterEvent(ActionType.EnterWay,AutoFindEvent);
				DetectionLogic.RegisterEvent(ActionType.EnterPoint,AutoFindEvent);
				DetectionLogic.RegisterEvent(ActionType.turnDone,AutoFindTurnDone);
				RC522.SetCallBack(AutoFindReadCard);
				lastIDCard=0;
				lastid=0;
				nowid=1;
				PathFind.InitFindPath();
				DetectionLogic.Control->ActionRun(Back);
				RecvCode=1;
				FindStatus=1;
				turnSpeed=10;
			}
			else{
				DetectionLogic.Control->StopRun();
				DetectionLogic.RegisterEvent(ActionType.EnterWay,RunInWay);
				DetectionLogic.RegisterEvent(ActionType.turnDone,RunTurnDone);
				DetectionLogic.RegisterEvent(ActionType.EnterPoint,RunInPoint);
				RC522.SetCallBack(RunReadCard);
				RecvCode=0;
			}
			break;
		case 8://Set Target Node
			TargetNodeID=e->ReadByte();
			if(TargetNodeID==PathFind.Finder->lastNodeID)break;
			lastid=StartNodeID=PathFind.Finder->lastNodeID;
			nowdir[0]=PathFind.Finder->paths[0];
			nowdir[1]=PathFind.Finder->paths[1];
			nowdir[2]=PathFind.Finder->paths[2];
			nowdir[3]=PathFind.Finder->paths[3];
			PathLen= PathFind.getTargetPath(TargetNodeID,pathbuff);
			if(PathLen!=0)
			{
				TargetNodeID=PathFind.Finder->lastNodeID;
				PathPos=0;
				RecvCode=0;
				PathFind.Rotate(nowdir,pathbuff[0]);
				nowid=PathFind.getNode(lastid)->nodes[nowdir[Forward]];
				//PathSelect|=PathType.Forward;
				lastLenght=PathFind.getNodeLenght(lastid,nowid);
				DetectionLogic.Control->ActionRun(pathbuff[0]);
			}
			break;
		case 9://Set Sensor TH
			Sensor.SetCHTH(e->ReadWord());
			break;
		case 10://Sensor SetZero
			Sensor.SetZero();
			break;
	}
}

void led(void)
{
  LED=~LED;
	UART.SendString((u8*)"test!");
	//mpu_dmp_get_data(&pitch,&roll,&yaw);
	//Yaw=yaw;
}

u8 StatusCheck(){
	static u8 Status;
	if(lastCheckStatus!=0){Wave.SetMode(0);return 0;}
	else Wave.SetMode(1);
	if(!Status)
	{
		if(Wave.CheckLength(detectionlenght)!=0xff)
		{
			Status=1;
			return 1;
		}
		return 0;
	}
	else{
		if(Wave.CheckLength(detectionlenght+50)==0xff){
			Status=0;
			return 0;
		}
		return 1;
	}
}

int main(void)
{
	Stm32_Clock_Init(9);
	JTAG_Set(1);
	Wave.init();
  Motor.Init();
  Sensor.Init();
	BatteryCheckInit();
  Timer.Init(72);
  LED_Init();
	KeyInit();

//  if(!MPU.Init());
  LED=0;
	
	UART.Init(72,115200,OnRecvData);
	UART.SendByte(0);
	
	RC522.Init();
	RC522.SetCallBack(RunReadCard);
	
	Timer.Start(0,UartProtocol.Check);
//  Timer.Start(0,tick1);
	Timer.Start(1,Wave.WaveScanLoop);
  Timer.Start(10,DetectionLogic.LogicRun);
	Timer.Start(1,Sensor.LoopScan);
	PathList=pathbuff;
	DetectionLogic.Init();
	DetectionLogic.RegisterEvent(ActionType.EnterWay,RunInWay);
	DetectionLogic.RegisterEvent(ActionType.EnterPoint,RunInPoint);
	DetectionLogic.RegisterEvent(ActionType.turnDone,RunTurnDone);
	DetectionLogic.SetDisableCheck(StatusCheck);
	DetectionLogic.Control->StopRun();
	lastAction=0xff;
	
	PathFind.Init(pathdatabuff,PathFindBuffSize,10);
	
	Timer.Start(1,KeyLoad);
	Timer.Start(0,RC522.ReadLoop);
	Timer.Start(500,UpdateBatteryValue);
	
  UartProtocol.Init(buffdata);
	UartProtocol.AutoAck(ENABLE);
	UartProtocol.RegisterCmd(Alive,AliveEvent);
  UartProtocol.RegisterCmd(GetData,GetDataEvent);
	UartProtocol.RegisterCmd(SetData,SetDataEvent);
	while(1)
		Timer.Run();
}
