#ifndef _PathFind_H_
#define _PathFind_H_

#include"mcuhead.h"

typedef struct {
	u8 nodes[4];
	u8 len[4];
	u8 lenmul;
	u8 tag;
}PathNode;

typedef struct {
	u8 nodeid;
	u32 id;
}NodeFlag;

typedef struct {
	u8 lastDir;
	u8 lastNodeID;
	u8 count;
	u32 stack;
	u8 paths[4];

}PathFinder;


#define PathNodeMaxCount 32
#define PathNodeFlagCount 10
#define PathFindBuffSize (PathNodeMaxCount*sizeof(PathNode)+(2*PathNodeMaxCount+7)/8+sizeof(NodeFlag)*PathNodeFlagCount) 

typedef struct {
	u8(*Init)(u8*,u16,u8);
	u8(*getEndPoint)(u8* EndPoints);
	u8(*getTargetPath)(u8 TargetNodeID, u8* Path);
	u8(*getFlagID)(u32 flag);
	u8(*getNodeDir)(u8 sid,u8 tid);
	u16(*getNodeLenght)(u8 srcid,u8 desid);
	PathNode*(*getNode)(u8 id);
	void(*setLastLenght)(u16);
	void(*setLastFlag)(u32,u8);
	u8(*getStatusFlag)(void);
	void(*Rotate)(u8* path,u8 dir);
	void(*RotateReset)(u8* path);
	u8(*getDir)(u8* path,u8 dir);
	void(*InitFindPath)(void);
	u8(*FindPath)( u8 pathtype);
	u16(*EncodeNode)(u8* outbuff);
	void(*DecodeNode)(u8* inbuff);
	PathFinder* Finder;
}PathFindBase;

extern const PathFindBase PathFind;

#endif
