#ifndef _IR_H_
#define _IR_H_

#include"mcuhead.h"

#define IR_PIN (GPIOB->IDR&BIT14)

#define IRC_CHD   	0x00A2
#define IRC_CH			0x0062
#define IRC_CHP		0x00E2
#define IRC_PREV		0x0022
#define IRC_NEXT		0x0002
#define IRC_PLAY		0x00C2
#define IRC_VOLD		0x00E0
#define IRC_VOLP		0x00AB
#define IRC_EQ			0x0090
#define IRC_0			0x0068
#define IRC_100P		0x0098
#define IRC_200P		0x00B0
#define IRC_1			0x0030
#define IRC_2			0x0018
#define IRC_3			0x007A
#define IRC_4			0x0010
#define IRC_5			0x0038
#define IRC_6			0x005A
#define IRC_7			0x0042
#define IRC_8			0x004A
#define IRC_9			0x0052

typedef void(*IRCallBack)(u16);

typedef struct {
	void(*Init)(void);
    void(*OnRecv)(IRCallBack);
    void(*Check)();
	void(*SetLoop)(u8);
}IRBase;

extern const IRBase IR;

#endif
