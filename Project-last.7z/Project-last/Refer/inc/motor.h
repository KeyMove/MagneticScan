#ifndef _Motor_H_
#define _Motor_H_

#include "mcuhead.h"

#define MOTOR_R_AB() SETBIT(GPIOC->BRR,BIT13|BIT15);SETBIT(GPIOC->BSRR,BIT15)
#define MOTOR_R_BA() SETBIT(GPIOC->BRR,BIT13|BIT15);SETBIT(GPIOC->BSRR,BIT13)
#define MOTOR_R_ST() SETBIT(GPIOC->BRR,BIT13|BIT15)

#define MOTOR_L_AB() SETBIT(GPIOC->BRR,BIT14|BIT0);SETBIT(GPIOC->BSRR,BIT0)
#define MOTOR_L_BA() SETBIT(GPIOC->BRR,BIT14|BIT0);SETBIT(GPIOC->BSRR,BIT14)
#define MOTOR_L_ST() SETBIT(GPIOC->BRR,BIT14|BIT0);

#define MOTOR_ENCODE (GPIOB->IDR&BIT3)

#define PosSensor 1

typedef struct {
	void(*Init)(void);
	void(*Speed)(u8 lr,s8 duty);
	void(*ResetPos)(void);
	u32(*GetPos)(u8 lr);
}MotorBase;

extern const MotorBase Motor;

#endif
