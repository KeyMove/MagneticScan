#include "Motor.h"
#include "sys.h"
static u32 MotorPos[PosSensor];
static void init(){
	SETBIT(RCC->APB1ENR,RCC_APB1ENR_TIM4EN);
	SETBIT(RCC->APB2ENR,RCC_APB2ENR_IOPBEN|RCC_APB2ENR_IOPCEN);
	GPIO_PP(GPIOC,11100000,00000001);
	GPIO_AF(GPIOB,00000011,0);
	SETBIT(GPIOB->ODR,BIT8|BIT9);
	SETBIT(GPIOC->ODR,BIT13|BIT14);
	TIM4->CR1|=TIM_CR1_ARPE;
	TIM4->CCER|=TIM_CCER_CC3E|TIM_CCER_CC4E;
	TIM4->PSC=72-1;
	TIM4->ARR=100-1;
	TIM4->CR1|=TIM_CR1_CEN;
	TIM4->CCMR2|=TIM_CCMR2_OC3M|TIM_CCMR2_OC3PE|TIM_CCMR2_OC3CE|TIM_CCMR2_OC4M|TIM_CCMR2_OC4PE|TIM_CCMR2_OC4CE;
	//TIM4->CCMR2|=TIM_CCMR2_OC3M|TIM_CCMR2_OC3PE|TIM_CCMR2_OC3CE|TIM_CCMR2_OC4M|TIM_CCMR2_OC4PE|TIM_CCMR2_OC4CE;	
	//TIM4->EGR|=TIM_EGR_UG;
	TIM4->CCR3=0;
	TIM4->CCR4=0;
	SETBIT(GPIOB->ODR,BIT5);
	GPIO_PU(GPIOB,0,00100000);
	Ex_NVIC_Config(1,5,1);
	NVIC_SetPriority(EXTI9_5_IRQn,2);
	NVIC_EnableIRQ(EXTI9_5_IRQn);
}

void EXTI9_5_IRQHandler(){
	SETBIT(EXTI->PR,BIT5);
	MotorPos[0]++;
}

static void SetZero(){
	u8 i;
	for(i=0;i<PosSensor;i++)
		MotorPos[i]=0;;
}

static u32 GetPos(u8 LR){
	return MotorPos[0];
}

static void setDuty(u8 LR,u8 duty){
	if(LR)
		TIM4->CCR3=duty;
	else
		TIM4->CCR4=duty;
}

static u8 motorstats;
static u8 motorstop=0xff;

#define vmax 32

static void setSpeed(u8 LR,s8 speed)
{
	if(speed>100)speed=100;
	if(speed<-100)speed=-100;
	speed=(s16)speed*(s16)100/(10000/vmax);
	
	if(!LR)
	{
		if(speed<0)
		{
			if(motorstats&BIT0||motorstop&BIT0)
			{
				CLRBIT(motorstop,BIT0);
				CLRBIT(motorstats,BIT0);
				MOTOR_L_AB();
			}
			setDuty(LR,vmax+speed);
		}
		else if(speed>0){
			if((!(motorstats&BIT0))||(motorstop&BIT0))
			{
				CLRBIT(motorstop,BIT0);
				SETBIT(motorstats,BIT0);
				MOTOR_L_BA();
			}
			setDuty(LR,vmax-speed);
		}
		else{
			SETBIT(motorstop,BIT0);
			setDuty(LR,100);
			MOTOR_L_ST();
		}
	}
	else
	{
		if(speed<0)
		{
			if(motorstats&BIT1||motorstop&BIT1)
			{
				CLRBIT(motorstop,BIT1);
				CLRBIT(motorstats,BIT1);
				MOTOR_R_BA();
			}
			setDuty(LR,vmax+speed);
		}
		else if(speed>0){
			if((!(motorstats&BIT1))||motorstop&BIT1)
			{
				CLRBIT(motorstop,BIT1);
				SETBIT(motorstats,BIT1);
				MOTOR_R_AB();
			}
			setDuty(LR,vmax-speed);
		}
		else{
			SETBIT(motorstop,BIT1);
			setDuty(LR,100);
			MOTOR_R_ST();
		}
	}
		
}

const MotorBase Motor = {
	init,	
	setSpeed,
	SetZero,
	GetPos,
};
