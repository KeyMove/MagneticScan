#include "wave.h"
#include "timer.h"

u16 *len1=0,*len2=0;

#define MaxPoint 3
#define RotAngle (90/MaxPoint)
static u16 LengthArray[MaxPoint];
static u8 Index;
static u8 TimeOut;
static u8 Mode;
static void GPIO_EX(u8 GPIOx,u8 BITx,u8 TRIM) 
{
	u8 EXTADDR;
	u8 EXTOFFSET;
	EXTADDR=BITx/4;//�õ��жϼĴ�����ı��
	EXTOFFSET=(BITx%4)*4; 
	RCC->APB2ENR|=0x01;//ʹ��io����ʱ��			 
	AFIO->EXTICR[EXTADDR]&=~(0x000F<<EXTOFFSET);//���ԭ�����ã�����
	AFIO->EXTICR[EXTADDR]|=GPIOx<<EXTOFFSET;//EXTI.BITxӳ�䵽GPIOx.BITx 
	//�Զ�����
	EXTI->IMR|=1<<BITx;//  ����line BITx�ϵ��ж�
	//EXTI->EMR|=1<<BITx;//������line BITx�ϵ��¼� (������������,��Ӳ�����ǿ��Ե�,���������������ʱ���޷������ж�!)
 	if(TRIM&0x01)EXTI->FTSR|=1<<BITx;//line BITx���¼��½��ش���
	if(TRIM&0x02)EXTI->RTSR|=1<<BITx;//line BITx���¼��������ش���
} 

static void Init(void)
{
  
  RCC->APB2ENR|=RCC_APB2ENR_IOPCEN|RCC_APB2ENR_IOPBEN;
	RCC->APB1ENR|=RCC_APB1ENR_TIM3EN;
	GPIO_PP(GPIOC,0,00100000);
	GPIO_AF(GPIOB,0,00000001);
	
	TIM3->PSC=72-1;
	TIM3->ARR=20000-1;
	
	TIM3->CCMR2=TIM_CCMR2_OC3M_1|TIM_CCMR2_OC3M_2|TIM_CCMR2_OC3PE;
	TIM3->CCER|=TIM_CCER_CC3E;
	TIM3->CR1=TIM_CR1_ARPE;
	TIM3->CR1|=TIM_CR1_CEN;
	
	TIM3->DIER|=TIM_DIER_UIE;
	NVIC_SetPriority(TIM3_IRQn,2);
	NVIC_EnableIRQ(TIM3_IRQn);
	
	GPIO_EX(1,1,3);
	NVIC_SetPriority(EXTI1_IRQn,2);
	NVIC_EnableIRQ(EXTI1_IRQn);
	//TIM3CapInit(0xffff,72-1);
	//TIM3->CCR3=500;
	Index=1;
	TimeOut=1;
	Wave.SetAngle(MaxPoint/2*5);
}


static void SetAngle(s16 value){
	TIM3->CCR3=800+11*value;
}

static void SetMode(u8 mode){
	Mode=mode;
	//SetAngle(MaxPoint/2*5);
}

static u8 CheckLength(u16 len){
	u8 i;
	for(i=0;i<MaxPoint;i++){
		if(LengthArray[i]<len)
		{
			return i;
		}
	}
	return 0xff;
}

static void WaveTrig(){
	Trig_SET();
	delay_us(20);
	Trig_CLR();
}
u8 enb=0;
u8 status;
static void WaveScanLoop(){
	
	if(TimeOut)
	{
		if(--TimeOut==0)
    {
			if(!enb)TimeOut=41;
      enb=1;
    }
    if(TimeOut==40)
		{
			WaveTrig();
			enb=0;
		}
    return;
	}
	if(!Mode)
	{
		WaveTrig();
		return;
	}
	if(enb)  
    TimeOut=100;
  if(status)
  {
    if(++Index>=MaxPoint)
		{
			Index=MaxPoint-2;
			status=0;
		}
  }
  else
  {
    if(--Index==0)
      status=1;
  }
  SetAngle(Index*RotAngle);
}

volatile u32 Timervalue;
volatile u32 TimerCount;
void EXTI1_IRQHandler(){
	s32 lenght;
	u32 len;
	EXTI->PR=2;
	if(Rec_Check()){
		Timervalue=TIM3->CNT;
		TimerCount=0;
	}
	else{
		len=TIM3->CNT;
		lenght=TimerCount*20000+len;
		lenght-=Timervalue;
		lenght=lenght*17/100;
		if(lenght<3000)
		{
			LengthArray[Index]=lenght;		
			enb=1;
		}
		TimeOut=1;
	}
}

void TIM3_IRQHandler(){
	if(TIM3->SR&TIM_SR_UIF)
	{
		TimerCount++;
		CLRBIT(TIM3->SR,TIM_SR_UIF);
	}
		
}


const WaveBase Wave={
  Init,
  WaveScanLoop,
	SetAngle,
	SetMode,
	CheckLength,
  //Time2Length,
};


