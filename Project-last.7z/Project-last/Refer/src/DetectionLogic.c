#include "DetectionLogic.h"
#include "PID.h"
#include "Sensor.h"
#include "motor.h"
//--------��·�滮-----------
//·������
u8 *PathList;
//·��ִ��λ��
u16 PathPos;
//·������
u16 PathLen;
//---------------------------

//-----------״̬-------------
//ת����ʱ��
u8 ReturnTime=30;
//ת���ٶ�
s8 turnSpeed=10;
//�м��·ʶ��ʱ��
u8 CentreWayTime=20;
//Ĭ�ϴ�����Ȩֵ
static const s8 DefPowerTable[] = {-25,-14,-12,-8,0,8,12,14,25};
//·�ڼ����ֵ
static u8 PowerThreshold = 14;
//·�ڼ��ȷ����ֵ
static u8 PowerMaxThreshold = 24;
//��·���
#define WayCentre (BIT12 | BIT11 | BIT10)
//��Ե���
#define WayEdge (BIT15|BIT7)
//ͣ������ʱ��
static u8 StopSpeedTime=30;

static u8 P;
//-----------------------------
enum WayType
{
	ForwardWay = BIT0,
	LeftWay = BIT1,
	RightWay = BIT2,
	EdgeWay=BIT3,
};

enum CheckStatus
{
	CheckWay=0,
	ConfirmWay=1,
	ReturnWay=2,
	PreTurn=3,
	TurnWay=4,
	TurnDone=5,
	Stop=6,
};

const CheckStatusBase CheckStatus={
	CheckWay,
	ConfirmWay,
	ReturnWay,
	PreTurn,
	TurnWay,
	TurnDone,
	Stop,
};

#define detecount 20
#define detetime 10
#define detewaycount 30
static DisableCallBack DisableCheck=0;
static u8 RunDir;
static u16 StatusTick;
static u8 lastError;

static u8 TargetDir=Back;
static u8 TargetSpeed=100;
s16 TargetTime=0;

static u8 PowerTableSize = sizeof(DefPowerTable);
static s8 *PowerTable = (s8*)DefPowerTable;
static u8 WayDetectionTime = detetime;
static u8 WayDetectionCount;
u8 WayCentreCount;
static u8 StopTime=0;
static u8 UpdateMotor;//�����ٶ�0Ϊ���� 1Ϊ������
u8 PathSelect;
s16 Yaw;

s8 MotorLeftSpeed=0;
s8 MotorRightSpeed=0;

PIDStruct LeftMotor;
PIDStruct RightMotor;

u8 lastCheckStatus;

static u8 lastLeftValue;
static u8 lastRightValue;
static u8 lastLeftTime;
static u8 lastRightTime;
static u8 lastStatus;
static u8 lastSpeed;
static u8 lastPathSelect;
//---------------״̬---------------


//--------------Ӧ�ò�----------------
ActionEvent eventlist[sizeof(ActionTypeBase)];

typedef struct {
	u8 Nop;
	u8 Stop;
	u8 turnLeft;
	u8 turnRight;
	u8 Forward;
	u8 Back;
	u8 FreeRun;
	u8 Stand;
}runStatusTypeBase;

//----------------����������--------------------------

//typedef void(*ActionEnter)(u8 lastPath);
//typedef void(*ActionLeave)(u8 lastPath);
//typedef void(*ActionFail)(u8 Dir,FailType type,u8 lastPath);

#define LogicAbs(x) ((x)<0?-x:x)

#define StatusM BIT0			//�������ĵ�λ��
#define StatusL BIT1			//ƫ��
#define StatusR BIT2			//ƫ��
#define StatusA BIT3			//ȫ�� ·��
//#define StatusLD BIT4   //ƫ��ȫ������
//#define StatusRD BIT5   //ƫ��ȫ������

#define WaveStop BIT6		//������ģ��������

#define CheckStatus(x) (lastStatus&(x))
#define CheckStatusZero() (Statuscount==0)

#define RunNop 0
#define RunNor 1
#define RunTor 2
#define RunTol 3
#define RunPts 4
#define RunTof 5
#define RunTob 6
#define RunStp 7

#define ModeTol 0
#define ModeTor 1
#define ModeTof 2
#define ModeTob 3
#define ModeRst 4

const PathTypeBase PathType = {
	StatusM,
	StatusL,
	StatusR,
};

const runStatusTypeBase runStatusType = {
	0,
	1,
	2,
	3,
	4,
	5,
	6,
};

const FailTypeBase FailType = {
	1,
	2,

};

const ActionTypeBase ActionType = {
	0,
	1,
	2,
	3,
	4,
	5,
};

void CheckReset(){
	lastCheckStatus=CheckWay;
	lastLeftTime=lastRightTime=0;
	lastLeftValue=lastRightValue=0;
	PathSelect=0;
}

void StopRun()
{
	CheckReset();
	PathPos = 0;
	Motor.Speed(0, MotorLeftSpeed = 0);
	Motor.Speed(1, MotorRightSpeed = 0);
}
//---------------------����������-----------------------------//

s16 TargetYaw,MinAngle;

//����YawĿ��Ƕ�
void SetTargetYaw(s16 deg) {
	TargetYaw = (s16)Yaw + 180 + deg;
	TargetYaw %= 360;
	MinAngle = deg + 180;
}

//---------------------�¼�����------------------------------//

static u8 getdir() {
	return RunDir;
}

static u8 ActionRun(u8 dir) {
	switch (dir)
	{
	case Forward:
		if(!(PathSelect&StatusM))return 0;
		lastCheckStatus=CheckWay;
		lastStatus=Forward;
		lastLeftTime=lastRightTime=0;
		lastLeftValue=lastRightValue=0;
		break;
	case Left:
		if (!(PathSelect&StatusL))return 0;
		lastCheckStatus=PreTurn;
		lastStatus=Left;
		lastLeftValue=0;
		WayDetectionCount=0;
		SetTargetYaw(90);
		
		break;
	case Right:
		if (!(PathSelect&StatusR))return 0;
		lastCheckStatus=PreTurn;
		lastStatus=Right;
		lastRightValue=0;
		WayDetectionCount=0;
		SetTargetYaw(-90);
		break;
	case Back:
		if ((PathSelect&(StatusL|StatusR))==(StatusL|StatusR)){
			lastStatus=Right;
			lastRightValue=0;
			WayDetectionCount=1;
		}
		else if(PathSelect&StatusL){
			lastRightValue=0;
			WayDetectionCount=0;
			lastStatus=Right;
		}
		else{
			lastLeftValue=0;
			WayDetectionCount=0;
			lastStatus=Left;
		}
		lastCheckStatus=PreTurn;
		SetTargetYaw(-180);
		break;
	}
	Motor.ResetPos();
	StopTime=ReturnTime;
	RunDir = dir;
	StatusTick = StopSpeedTime;
	TargetSpeed=100;
	return 1;
}

static u8 TargetAction(u8 dir){
	TargetDir=dir;
	return 1;
}

static void StopRunAction() {
	P=0;
	TargetSpeed=0;
	StatusTick = 0;
	lastCheckStatus=Stop;
	Motor.Speed(0, MotorLeftSpeed = 0);
	Motor.Speed(1, MotorRightSpeed = 0);
}

static u16 getTime() {
	return TargetTime;
}

static void setActionTime(u16 time)
{
	TargetTime=time;
}


static u8 getPath() {
	return PathSelect;
}

static u8 getPathCount() {
	return (((PathSelect&StatusL) != 0) + ((PathSelect&StatusM) != 0) + ((PathSelect&StatusR) != 0));
}

static u8 getLastError() {
	return lastError;
}

const ActionInfoBase ActionInfo = {
	getdir,
	ActionRun,
	TargetAction,
	StopRunAction,
	getTime,
	setActionTime,
	getPath,
	getPathCount,
	getLastError,
};
//-----------------------------------------------------//

//���Yaw�Ƿ�ӽ����ֵ
u8 CheckTargetYaw(u8 errdeg) {
	s16 Yawdeg = (s16)Yaw + 180;
	Yawdeg = TargetYaw - Yawdeg;
	if (Yawdeg > 180)
		Yawdeg = -(Yawdeg - 360);
	else if (Yawdeg < 0)
		Yawdeg = -Yawdeg;
	if (Yawdeg<errdeg)
		return 1;
	if (MinAngle > Yawdeg)
	{
		MinAngle = Yawdeg;
	}
	else if (MinAngle < Yawdeg) {
		if (eventlist[ActionType.turnFail]) {
			lastError = FailType.AngleOut;
			eventlist[ActionType.turnFail]((ActionData)&ActionInfo);
			StopRun();
		}
	}
	return 0;
}

//#define debug

#ifdef debug
u8 tc;
u8 tcv[100];
u8 tv[100];
#endif



s8 DetectionWay(u16 status) {
	s16 value;
	s8 v;
	u16 lv = 0, rv = 0;
	u8 lc = 0, rc = 0;
	u8 i;
	u8 waystatus=0;
	u8 pointcount = 0;
	u16 SensorValue;
	s16 SpeedLength;
	status=~status;
	SensorValue=status;
	UpdateMotor=1;
	if(lastCheckStatus==CheckWay)
	{
		if(status==0)
		{
			if(StopTime)
			{
				if(--StopTime==0)
				{
					UpdateMotor=0;
					Motor.Speed(0, MotorLeftSpeed = 0);
					Motor.Speed(1, MotorRightSpeed = 0);
					lastCheckStatus=Stop;
					StatusTick=StopSpeedTime;
					return lastSpeed;
				}
			}
			else if(lastSpeed){
					UpdateMotor=0;
					lastSpeed=0;
					Motor.Speed(0, MotorLeftSpeed = 0);
					Motor.Speed(1, MotorRightSpeed = 0);
					lastCheckStatus=Stop;
					return lastSpeed;
				}
		}
		else
			StopTime=ReturnTime;
	}
	value=0;
	if (status&WayEdge)
		SETBIT(waystatus,EdgeWay);
	if (status&WayCentre)
		SETBIT(waystatus, ForwardWay);
	for (i = 0; i < PowerTableSize; i++) {
		v = PowerTable[i];
		if ((status&BIT15)) {
			pointcount++;
			value+=v;
			if (v < 0) {
				if (v == (PowerTableSize - 1))
					SETBIT(waystatus, RightWay);				
				if (!(rc & 0x0f))
					rv = -v;
				else
					rv += -v;
				rc++;
			}
			else if (v>0) {
				if (i == 0)
					SETBIT(waystatus, LeftWay);
				if (!(lc & 0xf0))
				{
					lv += v;
					lc++;
				}
			}
		}
		else {
			if (v < 0) {
				if ((rc & 0x0f)>(rc >> 4)) {
					rc <<= 4;
				}
				else {
					rc &= 0xf0;
				}
			}
			else if (v>0) {
				if (!(lc&0xf0))
					lc <<= 4;
			}
		}
		status <<= 1;
	}

	if ((lc & 0xf0) > (lc & 0x0f))lc >>= 4;
	else lc &= 0x0f;

	if (rc & 0xf0)rc >>= 4;
	if (lc > 3)lc = 3;
	if (rc > 3)rc = 3;
	if(lc)lv /= lc;
	if(rc)rv /= rc;
	
	value/=pointcount;
	
	switch (lastCheckStatus) {
	case CheckWay:
		if(StatusTick==1)
		{
			
		}
		if (lastLeftTime) 
			if (--lastLeftTime == 0)
			{
				lastLeftValue = 0;
				CLRBIT(lastStatus,LeftWay);
			}
		if (lastRightTime)
			if (--lastRightTime == 0)
			{
					lastRightValue = 0;
				CLRBIT(lastStatus,RightWay);
			}
			
		if (((lastLeftValue < lv) || (lv>PowerMaxThreshold&&lc == 3))&&(SensorValue&BIT11)) {
			if(lastLeftTime<200)
				lastLeftTime += WayDetectionTime;
			lastLeftValue = lv;
			if ((lastLeftTime >= detecount)||(lv>PowerMaxThreshold&&lc == 3)) {
				if (lastLeftValue >= PowerThreshold)
				{
					#ifdef debug 
					tc=0; 
					Motor.Speed(0, 0);
					Motor.Speed(1, 0);
					#endif
					lastLeftValue = lastRightValue = 0;
					lastLeftTime=lastRightTime=0;					
					lastStatus=0;
					//SETBIT(lastStatus,LeftWay);
					lastCheckStatus = ConfirmWay;
					StatusTick=200;
					WayCentreCount = 0;
					WayDetectionCount=detewaycount;
					lv=rv=0;
				}
			}
		}
		else if(lastLeftValue > lv){
			lastLeftValue = lv;
			if (lastLeftTime > WayDetectionTime) {
				lastLeftTime -= WayDetectionTime;
			}
			else {
				lastLeftTime = 1;
			}
		}
		
		if (((lastRightValue < rv) || (rv>PowerMaxThreshold&&rc == 3))&&(SensorValue&BIT11)) {
			if(lastRightTime<200)
				lastRightTime += WayDetectionTime;
			lastRightValue = rv;
			if ((lastRightTime >= detecount)||(rv>PowerMaxThreshold&&rc == 3)) {
				if (lastRightValue >= PowerThreshold)
				{
					#ifdef debug 
					tc=0; 
					Motor.Speed(0, 0);
					Motor.Speed(1, 0);
					#endif
					lastLeftValue = lastRightValue = 0;
					lastLeftTime=lastRightTime=0;					
					lastStatus=0;
					//SETBIT(lastStatus,RightWay);
					lastCheckStatus = ConfirmWay;
					StatusTick=200;
					WayCentreCount = 0;
					WayDetectionCount=detewaycount;
					lv=rv=0;
				}
			}
		}
		else if(lastRightValue > rv){
			lastRightValue = lv;
			if (lastRightTime > WayDetectionTime) {
				lastRightTime -= WayDetectionTime;
			}
			else {
				lastRightTime = 1;
			}
		}

		break;
	case ConfirmWay:
		if (StatusTick == 0)
		{
			lastCheckStatus = CheckWay;
			lastLeftTime=lastRightTime=0;
			lastLeftValue=lastRightValue=0;
			lastStatus=0;
		}
		
		if(lastLeftValue<=PowerMaxThreshold&&lv!=0)
		lastLeftValue = (lastLeftValue * (u16)70 + lv * 30)/100;
		if(lastRightValue<=PowerMaxThreshold&&rv!=0)
		lastRightValue = (lastRightValue * (u16)70 + rv * 30)/100;

		#ifdef debug 
		tv[tc]=rv;
		tcv[tc]=lastRightValue;
		
		if(tc<100)
			tc++;
		else{
			Motor.Speed(0,0);
			Motor.Speed(1,0);
			tc=0;
		}
		#endif
		
//		if (waystatus&ForwardWay)
//			if(WayCentreCount<100)
//				WayCentreCount++;
		if ((lastLeftValue > PowerMaxThreshold) || (lastRightValue > PowerMaxThreshold)) {
			if(WayDetectionCount)
			{
				WayDetectionCount--;
				if((lastLeftValue > PowerMaxThreshold) && (lastRightValue > PowerMaxThreshold))
					if(WayDetectionCount>4)WayDetectionCount=4;
			}
			switch(TargetDir){
			case Left:
				if(!(lastLeftValue > PowerMaxThreshold))break;
				lastCheckStatus=ReturnWay;
				StatusTick=200;
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				TargetSpeed=30;
				P=0;
				SETBIT(lastPathSelect, ForwardWay);
				break;
			case Right:
				if(!(lastRightValue > PowerMaxThreshold))break;
				lastCheckStatus=ReturnWay;
				StatusTick=200;
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				TargetSpeed=30;
				P=0;
				SETBIT(lastPathSelect, ForwardWay);
				break;
			}
		}
		if (((lv < PowerThreshold && rv < PowerThreshold)&&((lastLeftValue > PowerMaxThreshold) || (lastRightValue > PowerMaxThreshold)))||WayDetectionCount==0) {
			#ifdef debug
			Motor.Speed(0,0);
			Motor.Speed(1,0);
			#endif
			if (lastLeftValue > PowerMaxThreshold)
				SETBIT(lastPathSelect, LeftWay);
			else
				CLRBIT(lastPathSelect, LeftWay);
			if (lastRightValue > PowerMaxThreshold)
				SETBIT(lastPathSelect, RightWay);
			else
				CLRBIT(lastPathSelect, RightWay);
			lastCheckStatus=ReturnWay;
			StatusTick=ReturnTime/2;
		}
		value=0;
		break;
	case ReturnWay://����
		if(TargetDir!=Back)
		{
			//UpdateMotor=0;	
			if(StatusTick==0)
			{
				lastCheckStatus=CheckStatus.CheckWay;
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				TargetSpeed=100;
				TargetDir=Back;
				Motor.ResetPos();
				TargetTime=0;
				if (eventlist[ActionType.TargeDone] != 0)
					eventlist[ActionType.TargeDone]((ActionData)&ActionInfo);
			}
			switch(TargetDir){
			case Forward:
				value=0;
				break;
			case Left:
				value=(StatusTick<150)?lv:25;
				break;
			case Right:
				value=(StatusTick<150)?-rv:-25;
				break;
			}
				
//			if(!(SensorValue&(~WayCentre)))
//				if(StatusTick>50)
//					StatusTick=50;
		}
		else{
			if (waystatus&ForwardWay)
				if(WayCentreCount<100)
					WayCentreCount++;
			if(StatusTick==0){
				Motor.Speed(0, MotorLeftSpeed = 0);
				Motor.Speed(1, MotorRightSpeed = 0);	
				if ((WayCentreCount >= CentreWayTime)||(SensorValue&WayCentre)) 
					SETBIT(lastPathSelect, ForwardWay);
				else
					CLRBIT(lastPathSelect, ForwardWay);
				PathSelect=lastPathSelect;
				lastStatus=0;
				UpdateMotor=0;	
				lastCheckStatus=Stop;
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				lastStatus=0;
				TargetSpeed=100;
				if (eventlist[ActionType.EnterWay] != 0)
					eventlist[ActionType.EnterWay]((ActionData)&ActionInfo);
			}
			if(waystatus&EdgeWay)
				value=0;
		}
		//value=value/(ReturnTime/StatusTick+1);
		break;
	case PreTurn://ת��Ԥ����
		TargetSpeed=0;
		TargetTime=0;
		if(StatusTick==0)
		{
			lastLeftTime=lastRightTime=0;
			lastLeftValue=lastRightValue=0;
			lastCheckStatus=TurnWay;
			TargetSpeed=100;
			P=0;
		}
		//Motor.Speed(0,0);
		//Motor.Speed(1,0);
		UpdateMotor=0;
		break;
	case TurnWay://ת��
		UpdateMotor=0;
		switch(lastStatus){
			case Forward:
				lastCheckStatus=CheckWay;
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				break;
			case Left:
				
			
				
				if(lastLeftValue>=PowerMaxThreshold)
				{
					if((lv<PowerThreshold)&&(waystatus&ForwardWay))
					{
						if(WayDetectionCount)
						{
							WayDetectionCount--;
							lastLeftValue=0;
						}
						else{
							lastCheckStatus=TurnDone;
							StatusTick=ReturnTime;
							if (eventlist[ActionType.turnPreDone] != 0)
								eventlist[ActionType.turnDone]((ActionData)&ActionInfo);
							TargetTime=0;
							TargetSpeed=100;
							P=0;
						}
					}
				}
				else
					lastLeftValue = (lastLeftValue * (u16)50 + lv * 50)/100;
				
				Motor.Speed(0, MotorLeftSpeed = -turnSpeed*P/100);
				Motor.Speed(1, MotorRightSpeed = +turnSpeed*P/100);
				//value=100;
				break;
			case Right:
				
				
				if(lastRightValue>PowerMaxThreshold)
				{
					if((rv<PowerThreshold))
					{
						if(WayDetectionCount)
						{
							WayDetectionCount--;
							lastRightValue=0;
						}
						else{
							lastCheckStatus=TurnDone;
							StatusTick=ReturnTime;
							if (eventlist[ActionType.turnPreDone] != 0)
								eventlist[ActionType.turnDone]((ActionData)&ActionInfo);
							TargetTime=0;
							TargetSpeed=100;
							P=0;
						}
					}
				}
				else 
					lastRightValue = (lastRightValue * (u16)50 + rv * 50)/100;
				
				Motor.Speed(0, MotorLeftSpeed = +turnSpeed*P/100);
				Motor.Speed(1, MotorRightSpeed = -turnSpeed*P/100);
				//value=-100;
				break;
		}
		break;
	case TurnDone://ת����ϵ���
			if(StatusTick==0){
				lastLeftTime=lastRightTime=0;
				lastLeftValue=lastRightValue=0;
				lastCheckStatus=CheckWay;
				if (eventlist[ActionType.turnDone] != 0)
						eventlist[ActionType.turnDone]((ActionData)&ActionInfo);
			}
			break;
	case Stop:
		UpdateMotor=0;
		if(StatusTick==1)
		{
			PathSelect=0;
			lastLeftTime=lastRightTime=0;
			lastLeftValue=lastRightValue=0;
			lastStatus=0;
			if (eventlist[ActionType.EnterPoint] != 0)
				eventlist[ActionType.EnterPoint]((ActionData)&ActionInfo);
		}
		break;
	}
	SpeedLength=TargetTime-Motor.GetPos(0);
	if(SpeedLength>0&&TargetTime!=0)
	{		
		if(SpeedLength<150)
			TargetSpeed=100;
		if(SpeedLength<50)
			if(TargetDir!=Forward)
				TargetSpeed=20;
		if(SpeedLength>300)
			TargetSpeed=200;
	}
	if(StatusTick)
		--StatusTick;
	if(lastCheckStatus!=Stop)
	{
		if(TargetSpeed>P)
			P++;
		else if(TargetSpeed<P)
			P--;
	}
	return (lastSpeed=value);
}


void LogicLoop() {
	s8 Speed;
	s16 L,R;
	if(DisableCheck)
		if(DisableCheck())
		{
			Motor.Speed(0, MotorLeftSpeed = 0);
				Motor.Speed(1, MotorRightSpeed = 0);
			P=0;
			return;
		}
	
	Speed = DetectionWay(Sensor.Read());
	
	if (!UpdateMotor)
		return;
	
//	if(P>150)
//	{
//		Motor.Speed(0, MotorLeftSpeed = 0);
//		Motor.Speed(1, MotorRightSpeed = 0);
//		P=P+1;
//	}
	L=PID.Update(&LeftMotor, +Speed);
	L*=P;
	L/=10;
	if(L>100)L=100;
	if(L<-100)L=-100;
	R=PID.Update(&RightMotor, -Speed);
	R*=P;
	R/=10;
	if(R>100)R=100;
	if(R<-100)R=-100;
	Motor.Speed(0,MotorLeftSpeed=(s8)L);
	Motor.Speed(1,MotorRightSpeed=(s8)R);
}

static void RegisterEvent(u8 type, ActionEvent e) {
	eventlist[type] = e;
}

static void inturndone(ActionData e)
{
	PathPos++;
	if(PathPos>=PathLen)
	{
		PathPos=0;
	}
}

static void inway(ActionData e) {
	switch (PathList[PathPos]) {
	case ModeTof:
		PathPos++;
		if(PathPos>=PathLen){
			PathPos=0;
		}
		if(!e->ActionRun(Forward)){
			StopRun();
		}
		break;
	case ModeTol:
		if (!e->ActionRun(Left))
			if (!e->ActionRun(Forward))
				StopRun();
		break;
	case ModeTor:
		if (!e->ActionRun(Right))
			if (!e->ActionRun(Forward))
				StopRun();
		break;
	}
}

static void inPoint(ActionData e) {
	if (PathList[PathPos] == ModeTob) {
		e->ActionRun(Back);
	}
	else {
		StopRun();
	}
}

static void DefConfig(u8* buff) {
	PathList = buff;
	DetectionLogic.RegisterEvent(ActionType.EnterPoint, inPoint);
	DetectionLogic.RegisterEvent(ActionType.EnterWay, inway);
	DetectionLogic.RegisterEvent(ActionType.turnDone,inturndone);
}

static void init(){
	PID.Init(&LeftMotor,100,80,50);
	PID.Init(&RightMotor,100,80,50);
	LeftMotor.value=10;
	RightMotor.value=10;
	LeftMotor.max=RightMotor.max=10;
	LeftMotor.min=RightMotor.min=-10;
	lastCheckStatus=Stop;
	WayDetectionTime = detetime;
	ReturnTime=30;
	turnSpeed=20;
	PowerThreshold = 12;
	PowerMaxThreshold = 14;
	StopSpeedTime=30;
	
	DisableCheck=0;
	//RunDir;
	StatusTick=0;
	//lastError;

	PowerTableSize = sizeof(DefPowerTable);
	PowerTable = (s8*)DefPowerTable;
	WayDetectionCount=0;
	WayCentreCount=0;
	StopTime=0;
	UpdateMotor=0;
	PathSelect=0;
	Yaw=0;
	lastCheckStatus=0;	
}

static void SetDisableCallBack(DisableCallBack callback){
	if(callback)
	{
		DisableCheck=callback;
	}
}

const DetectionLogicBase DetectionLogic = {
	init,
	LogicLoop,
	SetDisableCallBack,
	RegisterEvent,
	DefConfig,
	(ActionData)&ActionInfo,
};
