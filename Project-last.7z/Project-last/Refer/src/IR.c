#include"IR.h"
#include"Timer.h"
#include"sys.h"
static void init(){
	SETBIT(RCC->APB2ENR,RCC_APB2ENR_IOPBEN);
  GPIO_PU(GPIOB,01000000,00000000);
  Ex_NVIC_Config(1,14,3);
	NVIC_SetPriority(EXTI15_10_IRQn,1);
	NVIC_EnableIRQ(EXTI15_10_IRQn);
}
static u32 lastTick=0;
static u16 lastCount=0;
static u8 recvMode;

static u32 value;
static u8 index;
static u8 recvFlag;
static u16 recvData;

static IRCallBack callback;

static u8 setting=BIT0;

static u32 GetTime(){
  u32 v=TimerTick-lastTick;  
  u16 c=SysTick->VAL;
	c=9000-c;
	c/=9;
  v*=1000;
  v+=c;
  v-=lastCount;
  return v;
}

static void TimeStart(){
  lastTick=TimerTick;
  lastCount=SysTick->VAL;
	lastCount=9000-lastCount;
	lastCount/=9;
}

void EXTI15_10_IRQHandler(void)
{
  u32 v;
	if(!(EXTI->PR&BIT14))return;
	EXTI->PR=BIT14;
  v=GetTime();
  if(v>10000&&recvMode)
  {
    recvMode=0;
    return;
  }
	if(v>300000)
		recvData=0;
  if(IR_PIN){
    switch(recvMode){
    case 0:
      if(v>8500)
      {
        recvMode=1;
        TimeStart();  
      }
      break;
    case 1:
      break;
    case 2:
      TimeStart();
      break;
		case 3:
			recvMode=0;
			break;
    }
  }
  else{
    switch(recvMode)
    {
    case 0:
      TimeStart();
      break;
    case 1:
      if(v>4000)
      {
        recvMode=2;
        TimeStart();
        value=0;
        index=0;
      }
      else if(v>2000)
        recvFlag=(setting&BIT0)?1:0;
      else
        recvMode=0;
      break;
    case 2:
      value<<=1;
      if(v>1500)
        value++;
      if(++index>=32)
      {
        value^=0x00ff00ff;
        if((_32T8HH(value)==_32T8H(value))&&(_32T8L(value)==_32T8LL(value)))
        {
          _16T8H(recvData)=_32T8H(value);
          _16T8L(recvData)=_32T8L(value);
          recvFlag=1;
        }
        recvMode=3;
      }
      break;
    }
  }
}

static void SetCallBack(IRCallBack call){
  callback=call;
}

static void IRCheck(){
  if(!recvFlag)return;
  if(callback)
    callback(recvData);
  recvFlag=0;
}

void SetLoop(u8 b)
{
	recvData=0;
	CLRBIT(setting,BIT0);
	if(b)
		SETBIT(setting,BIT0);
}

const IRBase IR = {
	init,
    SetCallBack,
    IRCheck,
	SetLoop,
};
