#include "SpeedControl.h"

s8 nowL,nowR;
s8 targetL,targetR;
u8 Loop;
s8 sumL,sumR;

static void init(){
	nowL=nowR=0;
	targetL=targetR=0;
}

static void setSpeed(s8 L,s8 R){
	targetL=nowL-L<0?-L:L;
	targetR=R<0?-R:R;
	Loop=0;
}

static void Stop(){
	
}

static void SpeedControlLoop(){
	if(Loop>=100)return;
	
}

const SpeedControlBase SpeedControl = {
	init,	
};
