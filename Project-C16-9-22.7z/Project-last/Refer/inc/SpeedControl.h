#ifndef _SpeedControl_H_
#define _SpeedControl_H_

#include "mcuhead.h"

typedef struct {
	void(*Init)(void);
}SpeedControlBase;

extern const SpeedControlBase SpeedControl;

#endif
