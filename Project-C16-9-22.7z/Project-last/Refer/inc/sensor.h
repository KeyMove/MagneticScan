#ifndef _Sensor_H_
#define _Sensor_H_

#include "mcuhead.h"

#define HC595_CS_SET() SETBIT(GPIOA->BSRR,BIT0)
#define HC595_CS_CLR() SETBIT(GPIOA->BRR,BIT0)

#define MaxSensor 9

#if MaxSensor <= 8
#define SensorStatus u8
#endif
#if MaxSensor>8&&MaxSensor <= 16
#define SensorStatus u16
#endif
#if MaxSensor>16&&MaxSensor <= 32
#define SensorStatus u32
#endif
#if MaxSensor>32&&MaxSensor <= 64
#define SensorStatus u64
#endif

typedef struct {
	void(*Init)(void);
	void(*LoopScan)(void);
	SensorStatus(*Read)(void);
	void(*SetCHTH)(u16 value);
	u16(*GetCHValue)(u8 ch);
	void(*SetZero)(void);
}SensorBase;

extern const SensorBase Sensor;

#endif
