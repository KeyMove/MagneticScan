#include "Sensor.h"
#include "ADC.h"
#include "SPI.h"
#include "delay.h"

//const u16 defTH[]={1062,1046,1111,1070,1047,1102,1124,1060,1059};
const u16 defTH[]={1057,1034,1102,1061,1038,1092,1114,1051,1056};

SensorStatus Status=0;
//u16 THVA=600;
u16 THVA=1500;
u16 CHTH[MaxSensor];
u16 CHVA[MaxSensor];
u16 PutOut=0;

u8 CheckZero=2;
static u8 count;

void SwitchCH(u8 ch,u16 value)
{
  ch&=0x0f;
  if(ch>7)
    ch|=BIT3;
  else
    ch|=BIT4;
  ch<<=1;
  if(value&BIT8)
    ch|=BIT0;
  if(value&BIT9)
    ch|=BIT6;
  if(value&BIT10)
    ch|=BIT7;
  SPI.Write(value);
  SPI.Write(ch);
	HC595_CS_SET();
	delay_us(1);
  HC595_CS_CLR();
}

static void init(){
	u8 i;
	ADC.Init();
	SETBIT(RCC->APB2ENR, RCC_APB2ENR_IOPAEN);
	GPIO_AI(GPIOA,0,00000100);
	GPIO_PP(GPIOA, 0, 00000001);
	SPI.Init();
	SPI.Write(0x55);
	SPI.Write(0x55);
	HC595_CS_SET();
  HC595_CS_CLR();
	SPI.Write(0);
	SPI.Write(0);
	HC595_CS_SET();
  HC595_CS_CLR();
	for(i=0;i<MaxSensor;i++){
		CHVA[i]=0;
		CHTH[i]=defTH[i];
	}
	CheckZero=0;	
}

void clearCHTH()
{
	u8 i;
	for(i=0;i<MaxSensor;i++)
		CHTH[i]=1024;
}


u16 RTADC(){
	u32 v=0;
	u16 dat;
	u16 max=0;
	u16 min=0xffff;
	u8 i;
	for(i=0;i<10;i++)
	{
		dat=ADC.getADCValue(2);
		v+=dat;
		if(max<dat)
			max=dat;
		if(min>dat)
			min=dat;
	}
	v-=max+min;
	v/=8;
	return v;
}

static void Loop() {
	u16 value=RTADC();
	if(CheckZero){
		if(value==0)
		{
			CHTH[count]--;
			if(++count>=MaxSensor)
			{
				count=0;
				CheckZero--;
				if(CheckZero)				
					clearCHTH();
				SwitchCH(count,CHTH[count]);
				return;
			}
		}
		SwitchCH(count,++CHTH[count]);
		return;
	}
	CHVA[count] = value;
	if (value > THVA)
		SETBIT(Status, (u16)BIT7 << count);
	else
		CLRBIT(Status, (u16)BIT7 << count);
	if (++count >= MaxSensor) {
		count = 0;
		PutOut=Status;
	}
	SwitchCH(count,CHTH[count]);
}

static u16 getCHVA(u8 ch){
	return CHVA[ch];
}

static void setCHTH(u16 value){
	THVA=value;
}

static void SetZero(){
	clearCHTH();
	CheckZero=2;
	SwitchCH(count=0,1024);
}

static SensorStatus ReadData(){
	return ~PutOut;
}

const SensorBase Sensor = {
	init,	
	Loop,
	ReadData,
	setCHTH,
	getCHVA,
	SetZero,
};
