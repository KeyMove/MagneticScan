#include "PathFind.h"


PathNode *StartNode;
static u8 *PathList;
static u8 *PathFlagList;
u32 *BitCount;
u8 *Stack;
u8 PathListSize;
u8 NodeCount;
u8 PathFlagSize;
u8 PathFlagCount;
PathFinder Finder;
//u8 lastNodeID;

static u8 StatusFlag;

enum PathType
{
	nil = 0xff,
	Forward = 0,
	Left = 1,
	Right = 2,
	Back = 3,
};


static PathNode* getNewNode() {
	if (NodeCount < PathListSize)
	{
		return (PathNode*)&PathList[NodeCount++*sizeof(PathNode)];
	}
	return 0;
}

static u8 getNewNodeID() {
	if (NodeCount < PathListSize)
	{
		return NodeCount++;
	}
	return 0xff;
}

static PathNode* getPathNode(u8 id)
{
	if(id<PathListSize)
		return (PathNode*)&PathList[id*sizeof(PathNode)];
	return 0;
}

static void ClearNode() {
	u16 len = PathListSize*sizeof(PathNode);
	u16 i;
	for (i = 0; i < len; i++) {
		PathList[i] = 0xff;
	}
	BitCount = (u32*)Stack;
	PathFlagCount=0;
	NodeCount = 0;
}

const unsigned char mapdata[] = {
	0x00,0x09,0x00,0x01,0x00,0x08,0x00,0xFF,0x00,0xFF,0x00,0x01,0x02,0x00,0xFF,0x00,
	0x03,0x00,0x00,0x00,0x02,0xFF,0x00,0x04,0x00,0xFF,0x00,0x01,0x00,0x03,0xFF,0x00,
	0x01,0x00,0xFF,0x00,0xFF,0x00,0x04,0x07,0x00,0x06,0x00,0x02,0x00,0x05,0x00,0x05,
	0x04,0x00,0xFF,0x00,0xFF,0x00,0xFF,0x00,0x06,0xFF,0x00,0xFF,0x00,0x04,0x00,0xFF,
	0x00,0x07,0xFF,0x00,0xFF,0x00,0xFF,0x00,0x04,0x00,0x08,0xFF,0x00,0xFF,0x00,0x00,
	0x00,0xFF,0x00, };

const u8 testdata[] = { 1 + 4, 0, 2 + 4, 2, 1 + 2 + 4, 0, 1 + 2 + 4, 0, 1 + 2 + 4, 0, 1 + 2 + 4, 4, 1 + 2 , 4,0,2,1 + 4 };



static u8 init(u8 *buff,u16 len,u8 FlagCount) {

	u16 count=((len-(FlagCount*sizeof(NodeFlag)))*(u32)10)/(sizeof(PathNode)*10+2);
	if(count>255)
		count=255;
	Stack = buff;
	PathList = &buff[(2*count+7)/8];
	PathFlagList=PathList+count*sizeof(PathNode);
	PathListSize = count;
	PathFlagSize=FlagCount;
	BitCount = (u32*)Stack;
	StartNode = getPathNode(0);
	ClearNode();
	NodeCount = 0;
	return count;
//	Decode((u8*)mapdata);
//	len = PathFind.getNodePath(7, buff);
//	if (len == 0) {
//		NodeCount++;
//	}
//	PathFind.InitFindPath(&pf);
//	for (i = 0; i < sizeof(testdata); i++)
//		PathFind.FindPath(&pf, testdata[i]);
}

static void ClearFlag(){
	u8 i;
	for(i=0;i<NodeCount;i++){
		getPathNode(i)->tag=0xff;
	}
}

static u8 CheckEndPoint(PathNode *node) {
	u8 i;
	u8 count = 0;
	for (i = 0; i < 4; i++)
		if (node->nodes[i] != 0xff)
			if (++count == 2)
				return 1;
	return 0;
}

static void setLastLenght(u16 len)
{
	u8 f=Finder.paths[Back];
	PathNode *node=getPathNode(Finder.lastNodeID);
	node->len[f]=len;
	node->lenmul&=~(3<<(f*2));
	node->lenmul|=((_16T8H(len)&3)<<(f*2));
	node=getPathNode(node->nodes[f]);
	f=Finder.paths[Forward];
	node->len[f]=len;
	node->lenmul&=~(3<<(f*2));
	node->lenmul|=((_16T8H(len)&3)<<(f*2));
}

static u16 getNodeLenght(u8 sid,u8 tid){
	u16 len=0;
	u8 i;
	PathNode *node=getPathNode(sid);
	for(i=0;i<4;i++){
		if(node->nodes[i]==tid){
			_16T8H(len)=(node->lenmul>>(i*2))&3;
			_16T8L(len)=node->len[i];
			return len;
		}
	}
	return 0xffff;
}

static u8 getNodeDir(u8 sid,u8 tid){
	PathNode *node=getPathNode(sid);
	u8 i;
	for(i=0;i<4;i++)
		if(node->nodes[i]==tid)
			return i;
	return 0xff;
}

static void setNodeFlag(u32 id,u8 nodeid){
	u8 i;
	NodeFlag* flag;
	for(i=0;i<PathFlagCount;i++){
		flag=((NodeFlag*)(PathFlagList+i*sizeof(NodeFlag)));
		if(flag->nodeid==nodeid){
			flag->id=id;
			return;
		}
	}
	if(PathFlagCount<PathFlagSize)
	{
		PathFlagCount++;
		flag=((NodeFlag*)(PathFlagList+i*sizeof(NodeFlag)));
		flag->id=id;
		flag->nodeid=nodeid;
	}
}

static void setLastFlag(u32 id,u8 back)
{
	NodeFlag *flag;
	if(PathFlagCount<PathFlagSize){
		flag=(NodeFlag*)(PathFlagList+PathFlagCount*sizeof(NodeFlag));
		flag->id=id;
		if(back)
			flag->nodeid=getPathNode(Finder.lastNodeID)->nodes[Finder.paths[Back]];
		else
			flag->nodeid=Finder.lastNodeID;
		PathFlagCount++;
	}
}
	

static u8 getFlagID(u32 id)
{
	u8 i;
	NodeFlag *flag;
	for(i=0;i<PathFlagCount;i++)
	{
		flag=(NodeFlag*)(PathFlagList+i*sizeof(NodeFlag));
		if(flag->id==id)
			return flag->nodeid;
	}
	return nil;
}
	

static u8 getEndPoint(u8 *points) {
	u8 i;
	u8 count = 0;
	for (i = 0; i < NodeCount; i++) {
		if (!CheckEndPoint(getPathNode(i)))
		{
			if(points)
				*points++ = i;
			count++;
		}
	}
	return count;
}





static void Rotate(u8 *paths, u8 type) {
	u8 t;
	switch (type)
	{
	case Forward:break;
	case Left:
		t = paths[Forward];
		paths[Forward] = paths[Left];
		paths[Left] = paths[Back];
		paths[Back] = paths[Right];
		paths[Right] = t;
		break;
	case Right:
		t = paths[Left];
		paths[Left] = paths[Forward];
		paths[Forward] = paths[Right];
		paths[Right] = paths[Back];
		paths[Back] = t;
		break;
	case 3:
		t = paths[Forward];
		paths[Forward] = paths[Back];
		paths[Back] = t;
		t = paths[Left];
		paths[Left] = paths[Right];
		paths[Right] = t;
		break;
	}
}

static void RotateReset(u8 *paths) {
	paths[Forward] = Forward;
	paths[Left] = Left;
	paths[Right] = Right;
	paths[Back] = Back;
}

static u8 getDir(u8* paths, u8 type) {
	u8 i;
	for (i = 0; i < 4; i++) {
		if (paths[i] == type)
			return i;
	}
	return nil;
}

static u8 getStatusFlag(){
	return StatusFlag;
}

static void InitFindPath() {
	PathNode *node;
	ClearNode();
	Finder.count = 0;
	Finder.lastDir = 0;
	RotateReset(Finder.paths);
	Finder.stack = 0;
	node = getPathNode(Finder.lastNodeID = getNewNodeID());
	node = getPathNode(node->nodes[Forward] = getNewNodeID());
	node->nodes[Back] = Finder.lastNodeID;
	node->tag = 0;
	Finder.lastNodeID = getPathNode(Finder.lastNodeID)->nodes[Forward];
	StatusFlag=1;
}

static const u8 pathtable[] = { (1 << Right) + 0x20,(1 << Forward) + 0,(1 << Left) + 0x10 };
static u8 FindPath(u8 type) {
	u8 count = Finder.count;//ģ��ݹ�����
	u32 save = Finder.stack;//ģ��ݹ�ջ
	u8 i, id, j;//������ڽڵ�
	u8* paths = Finder.paths;//ת��ָʾ
	u8 PathOut = nil;//�������
	PathNode *node = getPathNode(Finder.lastNodeID);//��ǰ�ڵ�
	PathNode *targetnode=node;

	PathOut = nil;
	//������2D�Թ����� һֱ����ת��  ��ת���ȼ������� �� ��
	if(type!=0)
	for (j = 0; j < 3; j++) {
		if (type&pathtable[j]) {
			i = paths[pathtable[j] >> 4];//��ȡ��ͷĿ��ķ���
			if (node->nodes[i] == nil) {//���Ŀ�귽��Ϊ�� �½��ڵ㲢����
				targetnode = getPathNode(id = getNewNodeID());
				node->nodes[i] = id;
				PathOut = pathtable[j] >> 4;
				break;
			}
			else {//������ڽڵ���δʹ��
				id = node->nodes[i];
				targetnode = getPathNode(id);
				if (targetnode->tag) {
					PathOut = pathtable[j] >> 4;
					break;
				}
			}
		}
	}
	StatusFlag=0;
	//�����½ڵ�
	if (PathOut != nil) {
		StatusFlag=1;
		Rotate(paths, PathOut);//��ת��ͷ��Ŀ�귽��
		i = paths[Back];//Ŀ�귽��ĺ���Ϊ��ǰ�ڵ�
		node = targetnode;
		node->nodes[i] = Finder.lastNodeID;//�໥���ӽڵ�
		node->tag = 0;						//�����ʹ��
		if (count && (count % 16) == 0) {			//����16��֮�󻻵���һ����ַ
			*BitCount++ = save;
			save = 0;
		}
		save <<= 2;							//���淵�ؽڵ�id�� ռ��2bit�����غ�u32�ɱ���16��
		save |= i;
		Finder.count++;
		Finder.lastDir = PathOut;
		Finder.stack = save;
		Finder.lastNodeID = id;
		return PathOut;
	}
	if (Finder.count == 0)return nil;//����Ƿ��нڵ㻺��  û�������
	Finder.count--;
	i = save & 0x03;
	id = node->nodes[i];//��ȡ��һ���ڵ��id
	PathOut = getDir(paths, i);//��õ�ǰ�ڵ����һ���ڵ㷽�� ����������ͷ����
	Rotate(paths, PathOut);
	save >>= 2;
	if (count && (count % 16 == 0)) {//ȡ�������ֵ
		BitCount--;
		save = *BitCount;
	}
	Finder.lastDir = PathOut;
	Finder.stack = save;
	Finder.lastNodeID = id;
	return PathOut;
}

static void NodeToDir(u8 *nodes,u8 count){
	u8 *dirs=nodes;
	u8 dir;
	count--;
	while(count--){
		dir=getDir(Finder.paths,getNodeDir(*nodes,*(nodes+1)));
		*dirs++=dir;
		nodes++;
		Rotate(Finder.paths,dir);
	}
}

static u8 getNodePath(u8 targetid, u8* path) {
	u8 count = 0;
	u32 save = 0;
	u8 i, id, nowid = Finder.lastNodeID;
	PathNode *node = getPathNode(Finder.lastNodeID);
	PathNode *targetnode;
	if(targetid>=NodeCount)return 0;
	if(targetid==Finder.lastNodeID)return 0;
	ClearFlag();
	node->tag = 0;
	for (i = 0;;) {
		if (i > 3) {
			//������һ���ڵ�
			if (count == 0)return 0;//����Ƿ��нڵ㻺��  û�������
			count--;
			nowid = node->nodes[save & 0x03];//��ȡ��һ���ڵ��id
			node = getPathNode(nowid);//�����һ���ڵ��ַ
			i = 1;//����û��¼����ʱ��ѭ��ֵ ��1��ʼ
			save >>= 2;
			if (count && (count % 16 == 0)) {//ȡ�������ֵ
				BitCount--;
				save = *BitCount;
			}
			continue;
		}
		id = node->nodes[i];//��ȡ�ڵ�Ŀ��
		targetnode = 0;
		if (id != 0xff)
		{
			targetnode = getPathNode(id);
			if (!targetnode->tag)
				targetnode = 0;
		}
		if (targetnode == 0) {//����Ƿ�սڵ������ʹ�ù��ڵ�
			i++;
			continue;
		}
		//�����½ڵ�
		if (id != targetid) {		//����Ƿ�Ϊĩ�˽ڵ�
			if (!CheckEndPoint(targetnode)) {
				i++;
				continue;
			}
			node = targetnode;
			node->tag = 0;						//�����ʹ��
			for (i = 0; i < 4; i++)				//Ѱ�ҷ��غ�
				if (nowid == node->nodes[i])
					break;
			if (count)
				if ((count % 16) == 0) {			//����16��֮�󻻵���һ����ַ
					*BitCount++ = save;
					save = 0;
				}
			count++;
			save <<= 2;							//���淵�ؽڵ�id�� ռ��2bit�����غ�u32�ɱ���16��
			save |= i&3;
			nowid = id;							//���µ�ǰID��
			i = 0;
			continue;
		}
		i = count + 2;
		path[count + 1] = targetid;
		path[count] = nowid;
		while (count--) {
			id = node->nodes[save & 0x03];
			node = getPathNode(id);//�����һ���ڵ��ַ
			path[count] = id;
			save >>= 2;
			if (count && (count % 16 == 0)) {//ȡ�������ֵ
				BitCount--;
				save = *BitCount;
			}
		}
		NodeToDir(path,i);
		Finder.lastNodeID=targetid;
		//RotateReset(Finder.paths);
		//Rotate(Finder.paths, getNodeDir(path[i-2],path[i-1]));
		return i-1;
	}
}



static void Decode(u8* data) {
	PathNode* node;
	u8 *p = (u8*)&data[2];
	u8 i, j;
	u32 id;
	ClearNode();
	for (i = 0; i < data[1]; i++) {
		node = getNewNode();
		for (j = 0; j < 4; j++){
			node->nodes[j] = *p++;
			node->len[j] = *p++;
		}
		node->lenmul=0;
	}
	for(i=0;i<data[0];i++){
		j=*p++;
		_32T8HH(id)=*p++;
		_32T8H(id)=*p++;
		_32T8L(id)=*p++;
		_32T8LL(id)=*p++;
		setNodeFlag(id,j);
	}
	Finder.lastNodeID=1;
	RotateReset(Finder.paths);
}

static u16 Encode(u8* buff){
	u8* save=buff;
	u8 i;
	u8 j;
	PathNode *node;
	NodeFlag *flag;
	if(NodeCount==0)return 0;
	*buff++=PathFlagCount;
	*buff++=NodeCount;
	for(i=0;i<NodeCount;i++){
		node=getPathNode(i);
		for(j=0;j<4;j++)
		{
			*buff++=node->nodes[j];
			*buff++=node->len[j];
		}
	}
	for(i=0;i<PathFlagCount;i++){
		flag=(NodeFlag*)&PathFlagList[i*sizeof(NodeFlag)];
		*buff++=flag->nodeid;
		*buff++=_32T8HH(flag->id);
		*buff++=_32T8H(flag->id);
		*buff++=_32T8L(flag->id);
		*buff++=_32T8LL(flag->id);
	}
	return buff-save;
}

const PathFindBase PathFind = {
	init,
	getEndPoint,
	getNodePath,
	getFlagID,
	getNodeDir,
	getNodeLenght,
	getPathNode,
	setLastLenght,
	setLastFlag,
	getStatusFlag,
	Rotate,
	RotateReset,
	getDir,
	InitFindPath,
	FindPath,
	Encode,
	Decode,
	&Finder,
};
